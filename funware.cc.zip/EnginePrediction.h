#pragma once

#include "SDK.h"

void StartPrediction(CInput::CUserCmd* pCmd);
void EndPrediction(CInput::CUserCmd* pCmd);