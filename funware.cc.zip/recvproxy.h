

// Credits to Valve and Shad0w
#pragma once

void NetvarHook();
void UnloadProxy();