#pragma once

extern unsigned char CaviarDreams[55988];